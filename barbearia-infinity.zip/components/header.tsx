"use client"

import { Scissors } from "lucide-react"
import { useAuth } from "./auth-context"
import { Button } from "@/components/ui/button"

export function Header() {
  const { currentUser, logout, setLoginModalOpen, setRegisterModalOpen } = useAuth()

  return (
    <header className="fixed top-0 left-0 w-full bg-background/95 backdrop-blur-md z-50 border-b border-border/10">
      <div className="container mx-auto px-5 py-5">
        <nav className="flex justify-between items-center">
          <a href="#" className="flex items-center gap-2.5 text-foreground no-underline">
            <Scissors className="w-6 h-6 text-primary" />
            <span className="font-serif text-2xl font-bold tracking-wider">INFINITY</span>
          </a>

          <ul className="hidden md:flex gap-8 list-none">
            {[
              { href: "#hero", label: "Início" },
              { href: "#services", label: "Nossos Cortes" },
              { href: "#booking-section", label: "Agendar" },
              { href: "#location", label: "Localização" },
            ].map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-foreground/80 hover:text-primary transition-colors text-sm uppercase tracking-wider"
                >
                  {link.label}
                </a>
              </li>
            ))}
            {currentUser?.role === "admin" && (
              <li>
                <a href="#admin-panel" className="text-destructive text-sm uppercase tracking-wider">
                  Admin
                </a>
              </li>
            )}
          </ul>

          <div className="flex gap-3 items-center">
            {currentUser ? (
              <>
                <span className="text-sm hidden sm:block">Olá, {currentUser.name.split(" ")[0]}</span>
                <Button variant="outline" size="sm" onClick={logout}>
                  Sair
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={() => setLoginModalOpen(true)}>
                  Entrar
                </Button>
                <Button size="sm" onClick={() => setRegisterModalOpen(true)}>
                  Cadastrar
                </Button>
              </>
            )}
          </div>
        </nav>
      </div>
    </header>
  )
}
