"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "./auth-context"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function RegisterModal() {
  const { registerModalOpen, setRegisterModalOpen, setLoginModalOpen, register } = useAuth()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  if (!registerModalOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const success = register(name, email, password)
    if (success) {
      alert("Cadastro realizado com sucesso! Faça login.")
      setName("")
      setEmail("")
      setPassword("")
      setRegisterModalOpen(false)
      setTimeout(() => setLoginModalOpen(true), 150)
    } else {
      alert("Email já cadastrado.")
    }
  }

  const switchToLogin = () => {
    setRegisterModalOpen(false)
    setTimeout(() => setLoginModalOpen(true), 150)
  }

  return (
    <div
      className="fixed inset-0 z-[2000] bg-black/80 flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={() => setRegisterModalOpen(false)}
    >
      <div
        className="bg-card p-8 md:p-10 border border-primary w-full max-w-md relative animate-in zoom-in-95 slide-in-from-bottom-4 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => setRegisterModalOpen(false)}
          className="absolute top-3 right-4 text-white hover:text-primary transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="font-serif text-primary text-2xl mb-6 text-center">Criar Conta</h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block mb-2 text-primary text-sm">Nome Completo</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <div>
            <label className="block mb-2 text-primary text-sm">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <div>
            <label className="block mb-2 text-primary text-sm">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <Button type="submit" className="w-full">
            Cadastrar
          </Button>
          <p className="text-center text-sm">
            Já tem conta?{" "}
            <button type="button" onClick={switchToLogin} className="text-primary hover:underline">
              Faça Login
            </button>
          </p>
        </form>
      </div>
    </div>
  )
}
