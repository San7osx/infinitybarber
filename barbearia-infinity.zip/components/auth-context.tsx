"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  name: string
  email: string
  password: string
  role: "admin" | "user"
}

interface Appointment {
  id: number
  user: string
  service: string
  date: string
  time: string
  status: string
}

interface AuthContextType {
  currentUser: User | null
  appointments: Appointment[]
  login: (email: string, password: string) => boolean
  logout: () => void
  register: (name: string, email: string, password: string) => boolean
  saveAppointment: (service: string, date: string, time: string) => void
  isSlotTaken: (date: string, time: string) => boolean
  loginModalOpen: boolean
  setLoginModalOpen: (open: boolean) => void
  registerModalOpen: boolean
  setRegisterModalOpen: (open: boolean) => void
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [loginModalOpen, setLoginModalOpen] = useState(false)
  const [registerModalOpen, setRegisterModalOpen] = useState(false)
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    // Initialize storage
    if (!localStorage.getItem("infinity_users")) {
      const admin = { name: "Administrador", email: "admin", password: "password", role: "admin" as const }
      localStorage.setItem("infinity_users", JSON.stringify([admin]))
    }
    if (!localStorage.getItem("infinity_appointments")) {
      localStorage.setItem("infinity_appointments", JSON.stringify([]))
    }

    // Check session
    const session = sessionStorage.getItem("infinity_session")
    if (session) {
      setCurrentUser(JSON.parse(session))
    }

    setAppointments(JSON.parse(localStorage.getItem("infinity_appointments") || "[]"))
    setIsInitialized(true)
  }, [])

  const login = (email: string, password: string): boolean => {
    const users: User[] = JSON.parse(localStorage.getItem("infinity_users") || "[]")
    const user = users.find((u) => u.email === email && u.password === password)

    if (user) {
      setCurrentUser(user)
      sessionStorage.setItem("infinity_session", JSON.stringify(user))
      setLoginModalOpen(false)
      return true
    }
    return false
  }

  const logout = () => {
    sessionStorage.removeItem("infinity_session")
    setCurrentUser(null)
  }

  const register = (name: string, email: string, password: string): boolean => {
    const users: User[] = JSON.parse(localStorage.getItem("infinity_users") || "[]")
    if (users.find((u) => u.email === email)) {
      return false
    }
    const newUser: User = { name, email, password, role: "user" }
    users.push(newUser)
    localStorage.setItem("infinity_users", JSON.stringify(users))
    return true
  }

  const saveAppointment = (service: string, date: string, time: string) => {
    if (!currentUser) return

    const newAppt: Appointment = {
      id: Date.now(),
      user: currentUser.name,
      service,
      date,
      time,
      status: "Confirmado",
    }

    const updated = [...appointments, newAppt]
    setAppointments(updated)
    localStorage.setItem("infinity_appointments", JSON.stringify(updated))

    // WhatsApp redirect
    const phone = "5511999999999"
    const msg = `Olá! Gostaria de confirmar meu agendamento na Barbearia Infinity.%0A%0A*Nome:* ${currentUser.name}%0A*Serviço:* ${service}%0A*Data:* ${date}%0A*Horário:* ${time}`
    window.open(`https://wa.me/${phone}?text=${msg}`, "_blank")
  }

  const isSlotTaken = (date: string, time: string): boolean => {
    return appointments.some((a) => a.date === date && a.time === time)
  }

  if (!isInitialized) {
    return null
  }

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        appointments,
        login,
        logout,
        register,
        saveAppointment,
        isSlotTaken,
        loginModalOpen,
        setLoginModalOpen,
        registerModalOpen,
        setRegisterModalOpen,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}
