"use client"

import { AnimateIn } from "./animate-in"
import { Button } from "@/components/ui/button"

export function Location() {
  return (
    <section id="location" className="flex flex-wrap">
      <AnimateIn from="left" className="flex-1 min-w-[300px]">
        <div className="bg-card text-white p-12 md:p-20 flex flex-col justify-center h-full">
          <h2 className="font-serif text-primary text-4xl mb-6">Onde nos Encontrar</h2>

          <div className="mb-8">
            <h4 className="text-primary text-sm uppercase tracking-wider mb-2">Endereço</h4>
            <p className="text-muted-foreground text-lg">Av. Paulista, 1000 - Bela Vista</p>
            <p className="text-muted-foreground text-lg">São Paulo - SP, 01310-100</p>
          </div>

          <div className="mb-8">
            <h4 className="text-primary text-sm uppercase tracking-wider mb-2">Contato</h4>
            <p className="text-muted-foreground text-lg">(11) 99999-9999</p>
            <p className="text-muted-foreground text-lg">contato@infinitybarber.com</p>
          </div>

          <div className="mb-8">
            <h4 className="text-primary text-sm uppercase tracking-wider mb-2">Horários</h4>
            <p className="text-muted-foreground text-lg">Segunda a Sexta: 08h - 19h</p>
            <p className="text-muted-foreground text-lg">Sábado: 09h - 14h</p>
          </div>

          <Button variant="outline" asChild className="w-fit bg-transparent">
            <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer">
              Abrir no GPS
            </a>
          </Button>
        </div>
      </AnimateIn>

      <AnimateIn from="right" className="flex-1 min-w-[300px] md:min-w-[400px] h-[400px] md:h-[600px]">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.098170217036!2d-46.65402632375385!3d-23.564916861726053!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0aa315%3A0xd59f9431f2c9776a!2sAv.%20Paulista%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1709228391123!5m2!1spt-BR!2sbr"
          className="w-full h-full border-0 grayscale invert contrast-[83%]"
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      </AnimateIn>
    </section>
  )
}
