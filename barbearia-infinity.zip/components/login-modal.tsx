"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "./auth-context"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

export function LoginModal() {
  const { loginModalOpen, setLoginModalOpen, setRegisterModalOpen, login } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  if (!loginModalOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const success = login(email, password)
    if (!success) {
      alert("Credenciais inválidas. Tente: admin / password")
    } else {
      setEmail("")
      setPassword("")
    }
  }

  const switchToRegister = () => {
    setLoginModalOpen(false)
    setTimeout(() => setRegisterModalOpen(true), 150)
  }

  return (
    <div
      className="fixed inset-0 z-[2000] bg-black/80 flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={() => setLoginModalOpen(false)}
    >
      <div
        className="bg-card p-8 md:p-10 border border-primary w-full max-w-md relative animate-in zoom-in-95 slide-in-from-bottom-4 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => setLoginModalOpen(false)}
          className="absolute top-3 right-4 text-white hover:text-primary transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="font-serif text-primary text-2xl mb-6 text-center">Entrar</h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block mb-2 text-primary text-sm">Email</label>
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin ou seu email"
              required
              className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <div>
            <label className="block mb-2 text-primary text-sm">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
              required
              className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <Button type="submit" className="w-full">
            Entrar
          </Button>
          <p className="text-center text-sm">
            Não tem conta?{" "}
            <button type="button" onClick={switchToRegister} className="text-primary hover:underline">
              Cadastre-se
            </button>
          </p>
        </form>
      </div>
    </div>
  )
}
