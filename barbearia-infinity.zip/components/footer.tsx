import { Scissors } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-black py-10 text-center border-t border-border">
      <div className="container mx-auto px-5">
        <div className="flex items-center justify-center gap-2 text-white mb-5">
          <Scissors className="w-5 h-5 text-primary" />
          <span className="font-serif text-xl font-bold tracking-wider">INFINITY</span>
        </div>
        <p className="text-muted-foreground text-sm">© 2025 Barbearia Infinity. Todos os direitos reservados.</p>
      </div>
    </footer>
  )
}
