"use client"

import { Button } from "@/components/ui/button"
import { AnimateIn } from "./animate-in"

export function Hero() {
  return (
    <section
      id="hero"
      className="min-h-screen flex items-center relative pt-20"
      style={{
        background: `linear-gradient(to right, 
          rgba(18, 18, 18, 0.92) 35%, 
          rgba(18, 18, 18, 0.6) 65%, 
          rgba(18, 18, 18, 0.3) 100%),
          url('/images/img.jpg')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="container mx-auto px-5">
        <div className="max-w-xl">
          <AnimateIn delay={0} duration={500}>
            <h1 className="font-serif text-4xl md:text-6xl leading-tight mb-5 text-white">
              Redefinindo o Conceito de Barbearia Clássica
            </h1>
          </AnimateIn>
          <AnimateIn delay={100} duration={500}>
            <p className="text-muted-foreground text-lg mb-8">
              Estilo, precisão e uma experiência de luxo. Seu visual merece a excelência da Infinity.
            </p>
          </AnimateIn>
          <AnimateIn delay={200} duration={500}>
            <Button asChild size="lg" className="text-base">
              <a href="#booking-section">Agendar Agora</a>
            </Button>
          </AnimateIn>
        </div>
      </div>
    </section>
  )
}
