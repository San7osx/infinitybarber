"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "./auth-context"
import { Button } from "@/components/ui/button"
import { AnimateIn } from "./animate-in"
import { cn } from "@/lib/utils"

const serviceOptions = [
  { value: "Corte de Cabelo - R$ 40,00", label: "Corte de Cabelo (30min)" },
  { value: "Barba Tradicional - R$ 25,00", label: "Barba Tradicional (15min)" },
  { value: "Combo Corte + Barba - R$ 50,00", label: "Combo Corte + Barba + Sobrancelha (50min)" },
]

function generateSlots() {
  const slots: string[] = []
  for (let h = 8; h < 19; h++) {
    slots.push(`${h.toString().padStart(2, "0")}:00`)
    slots.push(`${h.toString().padStart(2, "0")}:30`)
  }
  return slots
}

function isValidDay(dateString: string) {
  const day = new Date(dateString + "T00:00:00").getDay()
  return day !== 0 && day !== 6
}

export function Booking() {
  const { currentUser, setLoginModalOpen, saveAppointment, isSlotTaken } = useAuth()
  const [service, setService] = useState(serviceOptions[0].value)
  const [date, setDate] = useState("")
  const [selectedTime, setSelectedTime] = useState("")

  const slots = generateSlots()
  const today = new Date().toISOString().split("T")[0]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedTime) {
      alert("Por favor, selecione um horário disponível.")
      return
    }
    saveAppointment(service, date, selectedTime)
    setDate("")
    setSelectedTime("")
  }

  return (
    <section id="booking-section" className="py-24 bg-card/50">
      <div className="container mx-auto px-5">
        <AnimateIn>
          <h2 className="font-serif text-4xl mb-12 text-primary text-center">Agende seu Horário</h2>
        </AnimateIn>

        <AnimateIn delay={100}>
          <div className="bg-card p-8 md:p-10 rounded border border-primary/20 max-w-2xl mx-auto">
            {!currentUser ? (
              <div className="text-center py-10">
                <p className="text-white mb-5">Você precisa estar logado para realizar um agendamento.</p>
                <Button onClick={() => setLoginModalOpen(true)}>Entrar na Minha Conta</Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block mb-2 text-primary text-sm">Serviço</label>
                  <select
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
                  >
                    {serviceOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block mb-2 text-primary text-sm">Data</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value)
                      setSelectedTime("")
                    }}
                    min={today}
                    required
                    className="w-full p-3 bg-background border border-border text-foreground focus:border-primary focus:outline-none"
                  />
                  <small className="text-muted-foreground text-xs mt-1 block">*Segunda a Sexta, 08:00 às 19:00</small>
                </div>

                <div>
                  <label className="block mb-2 text-primary text-sm">Horário Disponível</label>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 mt-4">
                    {!date ? (
                      <p className="col-span-full text-muted-foreground text-center">
                        Selecione uma data para ver os horários.
                      </p>
                    ) : !isValidDay(date) ? (
                      <p className="col-span-full text-destructive text-center">
                        Estamos fechados aos finais de semana. Por favor, escolha de Segunda a Sexta.
                      </p>
                    ) : (
                      slots.map((time, idx) => {
                        const taken = isSlotTaken(date, time)
                        return (
                          <button
                            key={time}
                            type="button"
                            disabled={taken}
                            onClick={() => setSelectedTime(time)}
                            className={cn(
                              "p-2.5 bg-background border border-border text-center text-sm transition-all duration-200",
                              taken && "opacity-30 cursor-not-allowed line-through",
                              !taken && "hover:border-primary hover:text-primary cursor-pointer",
                              selectedTime === time && "bg-primary text-background border-primary",
                            )}
                            style={{
                              animation: `fadeSlideIn 300ms ease-out ${idx * 20}ms both`,
                            }}
                          >
                            {time}
                          </button>
                        )
                      })
                    )}
                  </div>
                </div>

                <Button type="submit" className="w-full mt-4" size="lg">
                  Confirmar Agendamento
                </Button>
              </form>
            )}
          </div>
        </AnimateIn>
      </div>
    </section>
  )
}
