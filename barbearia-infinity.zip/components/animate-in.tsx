"use client"

import { useEffect, useRef, useState, type ReactNode } from "react"
import { cn } from "@/lib/utils"

interface AnimateInProps {
  children: ReactNode
  className?: string
  delay?: number
  duration?: number
  from?: "bottom" | "left" | "right" | "top" | "scale"
}

export function AnimateIn({ children, className, delay = 0, duration = 400, from = "bottom" }: AnimateInProps) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
          observer.disconnect()
        }
      },
      { threshold: 0.1, rootMargin: "50px" },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  const getInitialTransform = () => {
    switch (from) {
      case "bottom":
        return "translateY(20px)"
      case "top":
        return "translateY(-20px)"
      case "left":
        return "translateX(-20px)"
      case "right":
        return "translateX(20px)"
      case "scale":
        return "scale(0.95)"
      default:
        return "translateY(20px)"
    }
  }

  return (
    <div
      ref={ref}
      className={cn(className)}
      style={{
        opacity: isVisible ? 1 : 0,
        transform: isVisible ? "none" : getInitialTransform(),
        transition: `opacity ${duration}ms ease-out ${delay}ms, transform ${duration}ms ease-out ${delay}ms`,
        willChange: "opacity, transform",
      }}
    >
      {children}
    </div>
  )
}
