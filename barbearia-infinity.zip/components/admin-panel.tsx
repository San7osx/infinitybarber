"use client"

import { useAuth } from "./auth-context"
import { AnimateIn } from "./animate-in"

export function AdminPanel() {
  const { currentUser, appointments } = useAuth()

  if (currentUser?.role !== "admin") return null

  const sortedAppointments = [...appointments].sort(
    (a, b) => new Date(a.date + "T" + a.time).getTime() - new Date(b.date + "T" + b.time).getTime(),
  )

  return (
    <section id="admin-panel" className="py-24 bg-background border-t border-border">
      <div className="container mx-auto px-5">
        <AnimateIn>
          <h2 className="font-serif text-4xl mb-8 text-primary text-center">Painel Administrativo</h2>
        </AnimateIn>

        <AnimateIn delay={100}>
          <div className="bg-card p-6 rounded">
            <h3 className="text-white text-xl mb-5">Agendamentos Confirmados</h3>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-background">
                    <th className="p-4 text-left text-primary border-b border-border">Cliente</th>
                    <th className="p-4 text-left text-primary border-b border-border">Serviço</th>
                    <th className="p-4 text-left text-primary border-b border-border">Data</th>
                    <th className="p-4 text-left text-primary border-b border-border">Horário</th>
                    <th className="p-4 text-left text-primary border-b border-border">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedAppointments.map((appt) => (
                    <tr key={appt.id} className="hover:bg-card/80 transition-colors">
                      <td className="p-4 border-b border-border">{appt.user}</td>
                      <td className="p-4 border-b border-border">{appt.service.split("-")[0]}</td>
                      <td className="p-4 border-b border-border">{new Date(appt.date).toLocaleDateString("pt-BR")}</td>
                      <td className="p-4 border-b border-border">{appt.time}</td>
                      <td className="p-4 border-b border-border text-green-500">{appt.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </AnimateIn>
      </div>
    </section>
  )
}
