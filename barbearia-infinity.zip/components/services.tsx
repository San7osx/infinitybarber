"use client"

import { AnimateIn } from "./animate-in"
import Image from "next/image"

const services = [
  {
    title: "Corte Clássico",
    price: "R$ 40,00",
    description: "Tesoura e máquina com acabamento premium e lavagem incluída.",
    image:
      "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Barba Real",
    price: "R$ 25,00",
    description: "Toalha quente, navalha afiada e hidratação profunda.",
    image:
      "https://images.unsplash.com/photo-1621605815971-fbc98d665033?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
  },
  {
    title: "Infinity Combo",
    price: "R$ 50,00",
    description: "A experiência completa. Corte, Barba e Sobrancelha.",
    image: "/images/img.jpg",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-5">
        <AnimateIn>
          <h2 className="font-serif text-4xl mb-4 text-primary text-center">Nossos Serviços</h2>
        </AnimateIn>
        <AnimateIn delay={50}>
          <p className="text-center text-muted-foreground mb-12 max-w-lg mx-auto">
            Combinamos técnicas tradicionais com tendências modernas.
          </p>
        </AnimateIn>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <AnimateIn key={service.title} delay={index * 100} from="bottom">
              <div className="bg-card border border-border/10 overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-primary group">
                <div className="w-full h-80 overflow-hidden relative">
                  <Image
                    src={service.image || "/placeholder.svg"}
                    alt={service.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                </div>
                <div className="p-5 text-center">
                  <h3 className="font-serif text-2xl mb-1 text-white">{service.title}</h3>
                  <span className="text-primary font-bold text-lg block mb-3">{service.price}</span>
                  <p className="text-sm text-muted-foreground">{service.description}</p>
                </div>
              </div>
            </AnimateIn>
          ))}
        </div>
      </div>
    </section>
  )
}
