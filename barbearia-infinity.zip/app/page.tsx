"use client"

import { Hero } from "@/components/hero"
import { Services } from "@/components/services"
import { Booking } from "@/components/booking"
import { Location } from "@/components/location"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { LoginModal } from "@/components/login-modal"
import { RegisterModal } from "@/components/register-modal"
import { AdminPanel } from "@/components/admin-panel"
import { AuthProvider } from "@/components/auth-context"

export default function Home() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <main>
          <Hero />
          <Services />
          <Booking />
          <Location />
          <AdminPanel />
        </main>
        <Footer />
        <LoginModal />
        <RegisterModal />
      </div>
    </AuthProvider>
  )
}
